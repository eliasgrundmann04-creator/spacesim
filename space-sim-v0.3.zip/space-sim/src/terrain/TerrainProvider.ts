import type * as THREE from 'three/webgpu';
import { TerrainField, assembleTile } from './tileGeometry';
import type { TerrainSpec, TileSpec, TileBuffers } from './tileGeometry';
import { GpuTerrain } from './gpuTerrain';

/**
 * Zentrale Kachel-Fabrik für alle Planeten.
 *
 * Die Quadtree-Logik bleibt unverändert synchron und deterministisch — nur die
 * *Erzeugung* der Vertexpuffer ist asynchron geworden. Das ist die eigentliche
 * Ursache des Ruckelns: ein Kachel-Build kostete bisher mehrere Millisekunden
 * im Main-Thread, mitten im Frame.
 *
 * Backends:
 *   'worker' — Pool aus Web Workern (Standard). Parallel, transferable Puffer,
 *              funktioniert auch im WebGL2-Fallback (z. B. iPad-Safari).
 *   'gpu'    — WGSL-Compute via TSL; Höhen + Normalen von der GPU, Positionen
 *              weiterhin in f64 auf dem Main-Thread.
 *   'sync'   — Notfallpfad ohne Worker (nur wenn `Worker` fehlt).
 *
 * Priorisierung: Jobs tragen die Kameradistanz ihrer Kachel; abgearbeitet wird
 * immer die nächstgelegene. Weit entfernte Anfragen fallen bei voller Queue
 * heraus und werden im nächsten Frame ohnehin neu gestellt.
 */

export type TerrainBackend = 'worker' | 'gpu' | 'sync';
export type TerrainBackendChoice = TerrainBackend | 'auto';

export type TileCallback = (buffers: TileBuffers | null) => void;

interface Job {
  id: number;
  field: TerrainField;
  spec: TerrainSpec;
  tile: TileSpec;
  priority: number;      // Kameradistanz in m — kleiner = wichtiger
  callback: TileCallback;
}

const MAX_QUEUE = 96;
const JOBS_PER_WORKER = 2;
const GPU_IN_FLIGHT = 2;
const SYNC_PER_FRAME = 2;

class TerrainProvider {
  backend: TerrainBackend = 'sync';
  built = 0;

  private queue: Job[] = [];
  private readonly inflight = new Map<number, Job>();
  private nextId = 1;

  private workers: Worker[] = [];
  private readonly load = new Map<Worker, number>();

  private gpu: GpuTerrain | null = null;
  private gpuBusy = 0;
  private gpuFailures = 0;

  get workerCount(): number {
    return this.workers.length;
  }

  get pending(): number {
    return this.queue.length + this.inflight.size;
  }

  async configure(options: {
    renderer?: THREE.WebGPURenderer;
    backend?: TerrainBackendChoice;
    probe?: { field: TerrainField; tile: TileSpec };
  }): Promise<void> {
    // 'auto' wählt bewusst den Worker-Pfad: er ist parallel, läuft auch ohne
    // WebGPU und hat bei 19×19-Kacheln keine Readback-Latenz. Der GPU-Pfad
    // wird per ?terrain=gpu angefordert und spielt seine Stärke bei höheren
    // Kachelauflösungen aus (siehe README).
    const wanted = options.backend ?? 'auto';

    if (wanted === 'gpu' && options.renderer && options.probe) {
      const reference = referenceData(options.probe.field, options.probe.tile);
      this.gpu = await GpuTerrain.create(options.renderer, {
        field: options.probe.field,
        tile: options.probe.tile,
        reference,
      });
      if (this.gpu) {
        this.backend = 'gpu';
        return;
      }
      console.warn('[Terrain] GPU-Pfad nicht nutzbar — Fallback auf Worker.');
    }

    if (wanted !== 'sync' && typeof Worker !== 'undefined') {
      try {
        const count = Math.max(2, Math.min(4, (navigator.hardwareConcurrency || 4) - 1));
        for (let i = 0; i < count; i++) {
          const worker = new Worker(new URL('./terrainWorker.ts', import.meta.url), { type: 'module' });
          worker.onmessage = (e) => this.onWorkerMessage(worker, e);
          worker.onerror = (e) => console.error('[Terrain] Worker-Fehler', e);
          this.workers.push(worker);
          this.load.set(worker, 0);
        }
        this.backend = 'worker';
        return;
      } catch (e) {
        console.warn('[Terrain] Worker nicht verfügbar — synchroner Notfallpfad.', e);
        this.workers = [];
      }
    }

    this.backend = 'sync';
  }

  request(
    field: TerrainField,
    spec: TerrainSpec,
    tile: TileSpec,
    priority: number,
    callback: TileCallback,
  ): number {
    const id = this.nextId++;
    this.queue.push({ id, field, spec, tile, priority, callback });
    return id;
  }

  cancel(id: number): void {
    const qi = this.queue.findIndex((j) => j.id === id);
    if (qi >= 0) {
      this.queue.splice(qi, 1);
      return;
    }
    // Bereits vergeben: Ergebnis wird beim Eintreffen verworfen.
    this.inflight.delete(id);
  }

  /** Einmal pro Frame von der Engine aufgerufen: verteilt Jobs nach Priorität. */
  pump(): void {
    if (this.queue.length === 0) return;
    this.queue.sort((a, b) => a.priority - b.priority);

    if (this.queue.length > MAX_QUEUE) {
      for (const dropped of this.queue.splice(MAX_QUEUE)) dropped.callback(null);
    }

    switch (this.backend) {
      case 'worker': this.pumpWorkers(); break;
      case 'gpu': this.pumpGpu(); break;
      default: this.pumpSync(); break;
    }
  }

  // --------------------------------------------------------------- Worker

  private pumpWorkers(): void {
    let guard = this.workers.length * JOBS_PER_WORKER;
    while (guard-- > 0 && this.queue.length > 0) {
      const worker = this.leastLoadedWorker();
      if (!worker || (this.load.get(worker) ?? 0) >= JOBS_PER_WORKER) break;

      const job = this.queue.shift()!;
      this.inflight.set(job.id, job);
      this.load.set(worker, (this.load.get(worker) ?? 0) + 1);
      worker.postMessage({ jobId: job.id, spec: job.spec, tile: job.tile });
    }
  }

  private leastLoadedWorker(): Worker | null {
    let best: Worker | null = null;
    let bestLoad = Infinity;
    for (const w of this.workers) {
      const l = this.load.get(w) ?? 0;
      if (l < bestLoad) { bestLoad = l; best = w; }
    }
    return best;
  }

  private onWorkerMessage(worker: Worker, event: MessageEvent): void {
    const { jobId, positions, normals, colors, boundingRadius } = event.data;
    this.load.set(worker, Math.max(0, (this.load.get(worker) ?? 1) - 1));

    const job = this.inflight.get(jobId);
    if (!job) return; // zwischenzeitlich abgebrochen (Kachel gemerged/entsorgt)
    this.inflight.delete(jobId);
    this.built++;
    job.callback({ positions, normals, colors, boundingRadius });
  }

  // ------------------------------------------------------------------ GPU

  private pumpGpu(): void {
    while (this.gpu && this.gpuBusy < GPU_IN_FLIGHT && this.queue.length > 0) {
      const job = this.queue.shift()!;
      this.inflight.set(job.id, job);
      this.gpuBusy++;

      this.gpu.computeTile(job.field, job.tile)
        .then((data) => {
          this.gpuBusy--;
          if (!this.inflight.has(job.id)) return;
          this.inflight.delete(job.id);
          this.built++;
          // Positionen weiterhin in f64 auf dem Main-Thread (Präzision!)
          job.callback(assembleTile(job.field, job.tile, data));
        })
        .catch((e) => {
          this.gpuBusy--;
          this.inflight.delete(job.id);
          console.error('[Terrain] GPU-Dispatch fehlgeschlagen', e);
          job.callback(null);
          // Nach wiederholten Fehlern dauerhaft auf Worker umschalten,
          // statt jeden Frame erneut in denselben Fehler zu laufen.
          if (++this.gpuFailures > 8) {
            console.warn('[Terrain] GPU-Pfad instabil — dauerhafter Wechsel auf Worker.');
            this.gpu = null;
            void this.configure({ backend: 'worker' });
          }
        });
    }
  }

  // ----------------------------------------------------------------- Sync

  private pumpSync(): void {
    for (let i = 0; i < SYNC_PER_FRAME && this.queue.length > 0; i++) {
      const job = this.queue.shift()!;
      this.built++;
      job.callback(assembleTile(job.field, job.tile, null));
    }
  }

  dispose(): void {
    for (const w of this.workers) w.terminate();
    this.workers = [];
    this.queue = [];
    this.inflight.clear();
  }
}

/** CPU-Referenz (nx, ny, nz, raw) für den GPU-Selbsttest. */
function referenceData(field: TerrainField, tile: TileSpec): Float32Array {
  const buffers = assembleTile(field, tile, null);
  const count = buffers.normals.length / 3;
  const out = new Float32Array(count * 4);
  for (let i = 0; i < count; i++) {
    out[i * 4] = buffers.normals[i * 3];
    out[i * 4 + 1] = buffers.normals[i * 3 + 1];
    out[i * 4 + 2] = buffers.normals[i * 3 + 2];
    // Rohhöhe aus der Position zurückrechnen ist unnötig ungenau — direkt sampeln:
    const px = buffers.positions[i * 3] + tile.centerX;
    const py = buffers.positions[i * 3 + 1] + tile.centerY;
    const pz = buffers.positions[i * 3 + 2] + tile.centerZ;
    const l = Math.sqrt(px * px + py * py + pz * pz) || 1;
    out[i * 4 + 3] = field.rawHeight(px / l, py / l, pz / l);
  }
  return out;
}

let instance: TerrainProvider | null = null;

export function getTerrainProvider(): TerrainProvider {
  if (!instance) instance = new TerrainProvider();
  return instance;
}

export async function configureTerrainProvider(options: {
  renderer?: THREE.WebGPURenderer;
  backend?: TerrainBackendChoice;
  probe?: { field: TerrainField; tile: TileSpec };
}): Promise<TerrainBackend> {
  const provider = getTerrainProvider();
  await provider.configure(options);
  return provider.backend;
}

export type { TerrainProvider };
