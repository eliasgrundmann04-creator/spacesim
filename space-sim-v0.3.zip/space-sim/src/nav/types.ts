import type { Vec3 } from './vec';

/**
 * Minimalsicht auf einen Himmelskörper, wie die Navigation sie braucht.
 * Bewusst entkoppelt von `CelestialBody`: der Adapter in `Engine.ts` baut die Liste pro Frame.
 * Damit gilt §4.4 weiter — Katalog- und prozedurale Körper sind hier ununterscheidbar.
 */
export interface BodyRef {
  id: string;
  name?: string;
  /** Weltposition in m, bereits auf die aktuelle Simzeit propagiert. */
  position: Vec3;
  /** Mittlerer Oberflächenradius in m (ohne Atmosphäre). */
  radius: number;
  /**
   * Weltgeschwindigkeit in m pro **Realsekunde**, also Bahngeschwindigkeit × Time-Warp-Faktor.
   * Optional — fehlt sie, schätzt der Navigator sie aus aufeinanderfolgenden Frames.
   * Achtung: Kepler liefert m pro *Simsekunde*; vor der Übergabe mit dem Warp multiplizieren.
   */
  velocity?: Vec3;
}

/** Steuerkommando eines Frames. Alle Achsen −1…+1, im Kamerarahmen. */
export interface NavInput {
  /** Schub entlang der Blickrichtung. */
  forward: number;
  /** Seitwärts (positiv = rechts). */
  right: number;
  /** Hoch/runter entlang der Kamera-Oben-Achse. */
  up: number;
  /** Log-gestufter Multiplikator auf die Referenzgeschwindigkeit. */
  speedScale: number;
  /** Flugassistenz: dämpft die Relativgeschwindigkeit zum Ankerkörper auf 0. */
  assist: boolean;
  /** Einmaliger Vollstopp relativ zum Ankerkörper. */
  brake?: boolean;
}

export function neutralInput(): NavInput {
  return { forward: 0, right: 0, up: 0, speedScale: 1, assist: true, brake: false };
}

/** Orthonormale Kamerabasis + Weltposition, wie sie `SpaceCamera` pro Frame liefert. */
export interface NavFrame {
  position: Vec3;
  forward: Vec3;
  right: Vec3;
  up: Vec3;
}
