import * as THREE from 'three/webgpu';
import { Vector3d } from '../math/Vector3d';
import { LY } from '../core/constants';
import type { CelestialBody } from '../universe/CelestialBody';
import type { Vec3 } from '../nav/vec';

/**
 * Kamera für 20 Größenordnungen.
 *
 * Kernidee (Floating Origin): Die Three-Kamera steht IMMER bei (0,0,0).
 * Die "wahre" Position lebt als f64 in worldPosition; der SceneManager
 * platziert jede Frame alle Objekte relativ dazu. f32-Jitter entsteht im
 * Vertex-Shader durch große absolute Koordinaten — nicht im Depth-Buffer —
 * und genau diese großen Koordinaten erreichen die GPU hier nie.
 *
 * Zoom ist exponentiell (Distanz × e^k): dieselbe Geste bewegt nahtlos von 2 m
 * über einer Planetenoberfläche bis auf Lichtjahre hinaus. Genau deshalb passt
 * Pinch perfekt: das Verhältnis der Fingerabstände ist bereits multiplikativ
 * und wird unverändert auf die Zieldistanz angewandt.
 *
 * Ab v0.3 zwei Modi mit *einer* gemeinsamen Orientierung:
 *
 *   orbit — Position = Ziel − Blickrichtung × Distanz. Ziehen kreist um das Ziel,
 *           Pinch ändert die Distanz. Das bisherige Verhalten.
 *   free  — worldPosition ist maßgeblich und wird vom Navigator gesetzt. Ziehen
 *           dreht den Blick frei, Pinch schiebt entlang der Blickachse.
 *
 * theta/phi bedeuten in beiden Modi dasselbe: die **Blickrichtung**. Dadurch
 * teilen sich beide Modi Drehimpuls, Dämpfung und Eingabecode, und der
 * Moduswechsel ist sprungfrei — er ändert nur, woher die Position kommt.
 */

const MIN_DISTANCE = 0.5;
const MAX_DISTANCE = 500 * LY;

export type CameraMode = 'orbit' | 'free';

interface PointerState { x: number; y: number; }

export class SpaceCamera {
  readonly camera: THREE.PerspectiveCamera;
  readonly worldPosition = new Vector3d();

  target: CelestialBody | null = null;
  mode: CameraMode = 'orbit';

  // Blickrichtung in Z-up-Kugelkoordinaten (in beiden Modi identisch interpretiert)
  private theta = 0.6;
  private phi = 1.15;
  private distance = 1e7;
  private targetDistance = 1e7;

  // Drehimpuls: lässt Touch-Gesten natürlich auslaufen
  private thetaVel = 0;
  private phiVel = 0;

  // Freiflug: Höhe über dem Ankerkörper, vom Navigator pro Frame nachgereicht.
  // Sie ersetzt `distance` als Maßstab für Near-Plane und Pinch-Schub.
  private freeAltitude = 1e6;
  private pendingDolly = 1;

  private readonly pointers = new Map<number, PointerState>();
  private pinchDistance = 0;
  private pinchX = 0;
  private pinchY = 0;

  private readonly view = new THREE.Vector3();   // Blickrichtung
  private readonly radial = new THREE.Vector3(); // Zentrum → Kamera
  private readonly right = new THREE.Vector3();
  private readonly upVec = new THREE.Vector3();

  constructor(private readonly dom: HTMLElement) {
    this.camera = new THREE.PerspectiveCamera(
      55,
      window.innerWidth / window.innerHeight,
      0.2,
      1e19, // far ≫ 16 Lj Nachbarschaft; mit Log-Depth-Buffer unkritisch
    );
    this.camera.up.set(0, 0, 1); // Ekliptik, Z = Norden

    dom.style.touchAction = 'none';
    this.bindPointer();
  }

  // -------------------------------------------------------------- Eingabe

  private bindPointer(): void {
    const dom = this.dom;

    dom.addEventListener('pointerdown', (e) => {
      dom.setPointerCapture(e.pointerId);
      this.pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      this.thetaVel = 0;
      this.phiVel = 0;
      if (this.pointers.size === 2) this.beginPinch();
    });

    dom.addEventListener('pointermove', (e) => {
      const prev = this.pointers.get(e.pointerId);
      if (!prev) return;
      const dx = e.clientX - prev.x;
      const dy = e.clientY - prev.y;
      prev.x = e.clientX;
      prev.y = e.clientY;

      if (this.pointers.size === 1) this.rotateBy(dx, dy, 1);
      else if (this.pointers.size === 2) this.updatePinch();
    });

    const release = (e: PointerEvent): void => {
      if (!this.pointers.delete(e.pointerId)) return;
      if (dom.hasPointerCapture(e.pointerId)) dom.releasePointerCapture(e.pointerId);
      // Bei 3 → 2 Fingern die Pinch-Basis neu setzen, sonst springt der Zoom
      if (this.pointers.size === 2) this.beginPinch();
      else this.pinchDistance = 0;
    };
    dom.addEventListener('pointerup', release);
    dom.addEventListener('pointercancel', release);
    window.addEventListener('blur', () => {
      this.pointers.clear();
      this.pinchDistance = 0;
    });

    dom.addEventListener(
      'wheel',
      (e) => {
        e.preventDefault();
        this.zoomBy(Math.exp(e.deltaY * 0.0015));
      },
      { passive: false },
    );

    // iOS-Safari: Seiten-Zoom per Pinch unterbinden, damit die Geste bei uns ankommt
    for (const type of ['gesturestart', 'gesturechange', 'gestureend']) {
      dom.addEventListener(type, (e: Event) => e.preventDefault());
    }
    dom.addEventListener('contextmenu', (e) => e.preventDefault());
  }

  /** Sensitivität relativ zur kürzeren Bildschirmkante ⇒ auf Tablet und Desktop gleich. */
  private rotateBy(dx: number, dy: number, scale: number): void {
    const k = (2.2 / Math.min(window.innerWidth, window.innerHeight)) * scale;
    this.thetaVel = -dx * k;
    this.phiVel = -dy * k;
    this.theta += this.thetaVel;
    this.phi = THREE.MathUtils.clamp(this.phi + this.phiVel, 0.02, Math.PI - 0.02);
  }

  /**
   * Im Orbitmodus die Zieldistanz, im Freiflug ein Schub entlang der Blickachse.
   * Beides ist dieselbe Geste mit derselben Bedeutung — "näher ran" — nur einmal
   * als Bahnradius und einmal als Translation ausgedrückt.
   */
  private zoomBy(factor: number): void {
    if (this.mode === 'orbit') {
      this.targetDistance = THREE.MathUtils.clamp(
        this.targetDistance * factor, MIN_DISTANCE, MAX_DISTANCE,
      );
    } else {
      this.pendingDolly *= factor;
    }
  }

  private twoPointers(): [PointerState, PointerState] {
    const it = this.pointers.values();
    return [it.next().value as PointerState, it.next().value as PointerState];
  }

  private beginPinch(): void {
    const [a, b] = this.twoPointers();
    this.pinchDistance = Math.hypot(a.x - b.x, a.y - b.y) || 1;
    this.pinchX = (a.x + b.x) / 2;
    this.pinchY = (a.y + b.y) / 2;
  }

  private updatePinch(): void {
    const [a, b] = this.twoPointers();
    const dist = Math.hypot(a.x - b.x, a.y - b.y) || 1;
    const midX = (a.x + b.x) / 2;
    const midY = (a.y + b.y) / 2;

    if (this.pinchDistance > 0) {
      // Auseinanderziehen (dist wächst) ⇒ heranzoomen ⇒ Distanz sinkt
      this.zoomBy(this.pinchDistance / dist);
      // Zwei-Finger-Schwenk rotiert zusätzlich, gedämpft
      this.rotateBy(midX - this.pinchX, midY - this.pinchY, 0.6);
    }

    this.pinchDistance = dist;
    this.pinchX = midX;
    this.pinchY = midY;
  }

  // ------------------------------------------------------------ Steuerung

  /** Erstplatzierung ohne Übergang — nur beim Start. Danach läuft alles über Goto. */
  focus(body: CelestialBody): void {
    this.target = body;
    this.mode = 'orbit';
    this.targetDistance = body.radius * 6;
    this.distance = this.targetDistance;
    this.thetaVel = 0;
    this.phiVel = 0;
  }

  /**
   * In den Orbitmodus wechseln und Distanz sowie Blickrichtung aus der *aktuellen*
   * Position ableiten. Dadurch ist der Wechsel sprungfrei: die Kamera steht danach
   * exakt dort, wo der Anflug sie abgesetzt hat.
   */
  enterOrbit(body: CelestialBody): void {
    this.target = body;
    this.mode = 'orbit';
    this.pendingDolly = 1;

    const dx = this.worldPosition.x - body.position.x;
    const dy = this.worldPosition.y - body.position.y;
    const dz = this.worldPosition.z - body.position.z;
    const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
    if (d > 0) {
      this.distance = THREE.MathUtils.clamp(d, MIN_DISTANCE, MAX_DISTANCE);
      this.targetDistance = this.distance;
      // Blickrichtung zeigt zum Körper, also entgegen dem Radialvektor.
      this.setViewDirection(-dx / d, -dy / d, -dz / d);
    } else {
      this.distance = this.targetDistance = body.radius * 6;
    }
  }

  /** In den Freiflug wechseln. Position und Blickrichtung bleiben, wie sie sind. */
  enterFreeFlight(): void {
    if (this.mode === 'free') return;
    this.mode = 'free';
    this.pendingDolly = 1;
  }

  private setViewDirection(x: number, y: number, z: number): void {
    this.phi = Math.acos(THREE.MathUtils.clamp(z, -1, 1));
    this.phi = THREE.MathUtils.clamp(this.phi, 0.02, Math.PI - 0.02);
    this.theta = Math.atan2(y, x);
    // theta/phi sind die Quelle der Wahrheit; this.view wird sofort nachgezogen,
    // damit kein Aufrufer mit einem veralteten Vektor weiterrechnet.
    this.updateViewVector();
  }

  /**
   * Blick weich auf einen Weltpunkt ziehen (Anflug). Deutlich schneller als der
   * Anflug selbst — sonst schaut man noch am Ziel vorbei, wenn man längst da ist.
   */
  lookTowards(point: Vec3, dt: number, tau = 0.45): void {
    const dx = point.x - this.worldPosition.x;
    const dy = point.y - this.worldPosition.y;
    const dz = point.z - this.worldPosition.z;
    const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
    if (d <= 0) return;

    this.updateViewVector();
    const s = 1 - Math.exp(-dt / tau);
    const bx = this.view.x + (dx / d - this.view.x) * s;
    const by = this.view.y + (dy / d - this.view.y) * s;
    const bz = this.view.z + (dz / d - this.view.z) * s;
    const bl = Math.sqrt(bx * bx + by * by + bz * bz);
    if (bl <= 0) return;

    this.setViewDirection(bx / bl, by / bl, bz / bl);
    this.thetaVel = 0;
    this.phiVel = 0;
  }

  /** Für Bildschirm-Buttons auf Geräten ohne Tastatur/Mausrad. */
  zoomStep(direction: 1 | -1): void {
    this.zoomBy(Math.exp(direction * 0.35));
  }

  setWorldPosition(v: Vec3): void {
    this.worldPosition.set(v.x, v.y, v.z);
  }

  /** Höhe über dem Ankerkörper — im Freiflug der Maßstab für Near-Plane und Pinch. */
  setFreeAltitude(altitude: number): void {
    this.freeAltitude = Math.max(altitude, 1);
  }

  /**
   * Orthonormale Basis der Blickrichtung für den Navigator.
   * right = forward × up ist dieselbe Konvention wie in Three (lokal f=(0,0,−1),
   * u=(0,1,0), r=(1,0,0)); phi ist auf (0, π) geklemmt, forward also nie parallel zu Z.
   */
  basis(): { forward: Vec3; right: Vec3; up: Vec3 } {
    this.updateViewVector();
    this.right.copy(this.view).cross(this.camera.up).normalize();
    this.upVec.copy(this.right).cross(this.view).normalize();
    return {
      forward: { x: this.view.x, y: this.view.y, z: this.view.z },
      right: { x: this.right.x, y: this.right.y, z: this.right.z },
      up: { x: this.upVec.x, y: this.upVec.y, z: this.upVec.z },
    };
  }

  /**
   * Kollision auf Meter-Ebene: schiebt die Kamera bei Bedarf auf die lokale
   * Terrainhöhe. Liefert die Oberflächennormale, wenn geklemmt wurde — der
   * Aufrufer muss dann die einwärts gerichtete Geschwindigkeitskomponente
   * entfernen, sonst drückt der Schub in den Boden und die Kamera klebt fest.
   */
  clampToSurface(body: CelestialBody): Vec3 | null {
    const dx = this.worldPosition.x - body.position.x;
    const dy = this.worldPosition.y - body.position.y;
    const dz = this.worldPosition.z - body.position.z;
    const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
    if (d <= 0) return null;

    this.radial.set(dx / d, dy / d, dz / d);
    const minD = body.radius + body.getSurfaceOffset(this.radial) + 2;
    if (d >= minD) return null;

    this.worldPosition.set(
      body.position.x + this.radial.x * minD,
      body.position.y + this.radial.y * minD,
      body.position.z + this.radial.z * minD,
    );
    return { x: this.radial.x, y: this.radial.y, z: this.radial.z };
  }

  // -------------------------------------------------------------- Per Frame

  /**
   * Schritt 1: Orientierung. Läuft *vor* der Navigation, damit der Navigator mit
   * der Blickrichtung dieses Frames rechnet und nicht mit der des letzten.
   */
  updateOrientation(dt: number): void {
    if (this.pointers.size === 0 && (this.thetaVel !== 0 || this.phiVel !== 0)) {
      const decay = Math.exp(-dt * 5);
      this.thetaVel *= decay;
      this.phiVel *= decay;
      this.theta += this.thetaVel;
      this.phi = THREE.MathUtils.clamp(this.phi + this.phiVel, 0.02, Math.PI - 0.02);
      if (Math.abs(this.thetaVel) < 1e-5 && Math.abs(this.phiVel) < 1e-5) {
        this.thetaVel = 0;
        this.phiVel = 0;
      }
    }
    this.updateViewVector();
    // Der Pinch-Schub wird *vor* der Navigation eingerechnet, damit der Navigator
    // Nachbarschaft und Kollision für die tatsächlich neue Position auswertet.
    if (this.mode === 'free') this.applyDolly();
  }

  /** Schritt 2: Position und Projektion. Läuft *nach* der Navigation. */
  updatePlacement(dt: number): void {
    this.updateViewVector(); // lookTowards kann die Richtung zwischendurch gedreht haben
    if (this.mode === 'orbit') this.placeOrbit(dt);

    // Floating Origin: Kamera bleibt im Ursprung und blickt entlang der Blickrichtung
    this.camera.position.set(0, 0, 0);
    this.camera.lookAt(this.view.x, this.view.y, this.view.z);

    // Dynamische Near-Plane: verteilt die Log-Depth-Auflösung sinnvoll und
    // verbessert das Culling — von 20 cm am Boden bis 10^6 m im Deep Space.
    const near = THREE.MathUtils.clamp(Math.max(this.altitude, 1) * 1e-3, 0.2, 1e6);
    if (Math.abs(near - this.camera.near) / this.camera.near > 0.1) {
      this.camera.near = near;
      this.camera.updateProjectionMatrix();
    }
  }

  private placeOrbit(dt: number): void {
    const t = this.target;
    if (!t) return;

    // Zoom im Log-Raum glätten (gleichmäßig über alle Größenordnungen)
    const s = 1 - Math.exp(-dt * 8);
    this.distance = Math.exp(
      THREE.MathUtils.lerp(Math.log(this.distance), Math.log(this.targetDistance), s),
    );

    // Radialrichtung ist die Gegenrichtung des Blicks ⇒ Bodenhöhe dort sampeln
    this.radial.copy(this.view).multiplyScalar(-1);
    const minD = t.radius + t.getSurfaceOffset(this.radial) + 2;
    if (this.targetDistance < minD) this.targetDistance = minD;
    if (this.distance < minD) this.distance = minD;

    this.worldPosition.set(
      t.position.x + this.radial.x * this.distance,
      t.position.y + this.radial.y * this.distance,
      t.position.z + this.radial.z * this.distance,
    );
  }

  private applyDolly(): void {
    if (this.pendingDolly === 1) return;
    // Pinch/Rad im Freiflug: Translation entlang der Blickachse, skaliert mit der
    // Ankerhöhe — damit fühlt sich die Geste in 2 m und in 2 AE identisch an.
    const step = THREE.MathUtils.clamp(
      this.freeAltitude * (1 - this.pendingDolly),
      -4 * this.freeAltitude,
      0.9 * this.freeAltitude,
    );
    this.worldPosition.set(
      this.worldPosition.x + this.view.x * step,
      this.worldPosition.y + this.view.y * step,
      this.worldPosition.z + this.view.z * step,
    );
    this.pendingDolly = 1;
  }

  private updateViewVector(): void {
    const sinPhi = Math.sin(this.phi);
    this.view.set(
      sinPhi * Math.cos(this.theta),
      sinPhi * Math.sin(this.theta),
      Math.cos(this.phi),
    );
  }

  get altitude(): number {
    if (this.mode === 'free') return this.freeAltitude;
    return this.target ? this.distance - this.target.radius : 0;
  }

  resize(width: number, height: number): void {
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
  }

  get fovYRadians(): number {
    return (this.camera.fov * Math.PI) / 180;
  }
}
