# Space Sim — Navigation (v0.3)

Physikalisch realistischer Weltraumsimulator (SpaceEngine-Stil).
TypeScript · Three.js (WebGPU-Renderer, `three/webgpu`) · Vite.

**Neu in v0.3 — Stufe 1 „Navigation & Übergänge":** freier Flug mit skalenfreiem Geschwindigkeitsmodell, weiche Zielübergänge im Log-Raum statt Sprüngen, Winkel-Picking per Doppeltipp, Schubregler. Details unten unter *Navigation*.

*Neu in v0.2:* asynchrone Terrain-Erzeugung (Web-Worker-Pool + optionaler WGSL-Compute-Pfad via TSL) und vollständige Touch-Bedienung inkl. Pinch-to-Zoom.

## Setup

Voraussetzungen: Node ≥ 18. WebGPU: Chrome/Edge 113+ (andere Browser nutzen automatisch den WebGL2-Fallback des `WebGPURenderer`).

```bash
npm install
npm run dev        # → http://localhost:5173
```

Geschrieben gegen `three@0.171` / `@types/three@0.171` (gepinnt).

Offline-Prüfungen (brauchen weder Netz noch `node_modules`, Node ≥ 22.6):

```bash
npm run test:nav     # 41 Tests der Navigationskerne
npm run test:orbit   # 10 Tests der Kepler-Zustandspropagation
npm run typecheck    # strikt; ohne node_modules bleiben nur TS2307 übrig
```

## Steuerung

| Touch | Maus/Tastatur | Wirkung |
|---|---|---|
| Ein Finger ziehen | Ziehen | Orbit: um das Ziel rotieren · Freiflug: Blickrichtung drehen (läuft mit Drehimpuls aus) |
| **Pinch** (zwei Finger) | Scrollen | Orbit: exponentieller Zoom · Freiflug: Schub entlang der Blickachse |
| **Schubregler** (rechts) | — | Vorwärts/rückwärts fliegen; federt beim Loslassen auf 0 zurück |
| **`− ×N +`** | — | Geschwindigkeitsstufe, √10 pro Schritt, ×0,001 … ×100 |
| **`ASSIST`** | — | Relativgeschwindigkeit zum Ankerkörper ausdämpfen (an = Standard) |
| **`STOP`** | — | Sofortiger Vollstopp relativ zum Anker |
| **Doppeltipp auf einen Körper** | Doppelklick | Anflug starten |
| ◀ ▶ | Tab / Shift+Tab | Ziel durchschalten — ab v0.3 als sichtbarer Flug |
| − + | Scrollen | Zoomen bzw. schieben in Stufen |
| ≪ ×n ≫ ❚❚ | `,` `.` `0` `P` | Zeitraffer langsamer / schneller / zurücksetzen / Pause |
| — | 1–9 | Direktwahl (1 = Sonne, 4 = Erde, 5 = Mond, …) |

Der Pinch-Faktor wird direkt als Multiplikator verwendet: Fingerabstands-*Verhältnis*, exponentieller Zoom und das Geschwindigkeitsmodell sind alle drei multiplikativ, deshalb fühlt sich die Geste über alle 20 Größenordnungen gleich an.

Demo-Pfad: Erde fokussieren → Schubregler nach oben, Stufe ×10 → in wenigen Sekunden zum Mond fliegen, ganz ohne Zielauswahl → Regler loslassen, die Assistenz bremst relativ zum Mond aus → Zeitraffer auf ×10⁶ stellen: die Kamera bleibt über dem Mond stehen, statt zurückzufallen → Doppeltipp auf die Sonne für einen Anflug → mit ▶ einen `PSC-*`-Stern wählen, sein System wird beim Anflug lazy generiert.

## Navigation (Stufe 1)

**Geschwindigkeit ∝ Referenzhöhe ⇒ logarithmische Flugzeit.** `v = rate · h · speedScale` ergibt `dh/dt = ±rate·h`, also `h(t) = h₀·e^(±rate·t)`. Die Flugzeit hängt nur vom *Verhältnis* der Höhen ab: von 2 m auf 1 AE dauert genauso lange wie zurück und in derselben Größenordnung wie ein Flug zum Nachbarstern. Der Offline-Test misst Erde↔Mond mit 24,10 s hin und 24,10 s zurück — die Symmetrie ist die Aussage des Modells, nicht Zufall. Untergrenze `minAltitude = 2 m`, sonst wäre die Oberfläche asymptotisch unerreichbar (Zeno).

**Weiches Minimum im Logarithmus der Höhe.** Ein hartes `min` über alle Körper springt, sobald beim Vorbeiflug ein anderer Körper der nächste wird. Gemischt wird deshalb weich — aber im Logarithmus, weil die Höhen über 20 Größenordnungen streuen. Verwendet wird der gewichtete Boltzmann-Mittelwert, **nicht** log-sum-exp: Letzteres zieht das Ergebnis mit jedem weiteren gleich weit entfernten Körper nach unten, 200 Sterne in gleicher Distanz ergäben eine fünffach zu niedrige Referenz.

**Der Flugzustand ist die *ankerrelative* Geschwindigkeit.** Bei Time-Warp ×10⁸ rast die Erde mit ~10¹² m/s durch den Weltframe. Dämpfte die Assistenz eine *Welt*geschwindigkeit auf null, bliebe man beim Einschalten des Warps um `v_Rahmen · τ` zurück — der Planet wäre weg. Gespeichert wird deshalb die Geschwindigkeit relativ zum Anker; die Rahmengeschwindigkeit kommt analytisch aus Kepler (neu: `CelestialBody.velocity`, entlang desselben Baums akkumuliert wie die Position) und wird ohne Übergangszeit addiert. Beim Ankerwechsel wird nur so viel Trägheit übernommen, wie die eigene Bewegungsskala verträgt — bei realistischem Tempo bleibt sie erhalten, bei Warp gewinnt die Mitführung. Sauber löst das erst der Frame-Baum (Stufe 2).

**Anflug relativ zum Ziel, nicht absolut.** `ln d(τ) = lerp(ln d₀, ln d₁, smootherstep(τ))` — konstante *relative* Annäherung, dieselbe Größe wie im freien Flug. Die Bahn wird jedes Frame gegen die *aktuelle* Zielposition ausgewertet; bei hohem Warp legt der Mond während eines 3,4-s-Anflugs mehrere Umläufe zurück, ein vorberechneter Weltpfad führte ins Leere. `smootherstep` statt `smoothstep`, weil erste **und** zweite Ableitung an beiden Rändern verschwinden müssen. Die Übergabegeschwindigkeit wird analytisch gerechnet (Ableitung von Log-Interpolation und Slerp) statt per Rückwärtsdifferenz — die hinterließ ~3 km/s Restschließgeschwindigkeit, die Ableitung ist bei τ = 1 exakt null. Dauer: `1,1 s + 0,55 s je e-Faltung + 1,2 s je 180°`, geklemmt auf 1,6 … 8 s.

**Picking im Winkelraum.** Ein Körper kann 10⁻⁹ px oder den halben Bildschirm groß sein; ein fester Pixelradius trifft entweder nichts oder alles. Bewertet wird der Fehlwinkel zum Scheibenrand `miss = max(0, θ − asin(R/d))`, Treffer *innerhalb* der Scheibe gewinnen, davon der nächste — sonst würde ein ferner Stern durch einen Planeten hindurch ausgewählt.

**Zwei Kameramodi, eine Orientierung.** `theta/phi` bedeuten in beiden Modi die Blickrichtung; nur die Herkunft der Position unterscheidet sich (Orbit: aus dem Ziel abgeleitet, Freiflug: vom Navigator gesetzt). Dadurch teilen sich beide Modi Eingabe, Drehimpuls und Dämpfung, und der Wechsel ist sprungfrei. Ein Anflug endet im Orbitmodus um das Ziel, ein *abgebrochener* Anflug bleibt im Freiflug.

**Auflösungsdeckel statt Geschwindigkeitsdeckel.** Pro Frame ändert sich der Abstand zum Anker um höchstens 1,5 Referenzhöhen. Das ist keine Bequemlichkeit: weder Kollisionsprüfung noch LOD könnten einem Frame folgen, der von 1 AE in den Sonnenkern führt. Praktisch begrenzt das den wirksamen Multiplikator bei 60 fps auf ~×100, bei 20 fps auf ~×33.

## Terrain-Backends

Das HUD zeigt das aktive Backend, die Queue-Länge und die Zahl gebauter Kacheln.

| URL | Backend | Beschreibung |
|---|---|---|
| *(Standard)* | `worker` | Pool aus 2–4 Web Workern, Ergebnisse als Transferables |
| `?terrain=gpu` | `gpu` | Höhenfeld + Normalen als WGSL-Compute-Kernel (TSL) |
| `?terrain=sync` | `sync` | Notfallpfad im Main-Thread (nur zum Vergleich/Debuggen) |

**Warum Worker der Standard ist:** bei 19×19-Kacheln (~1.1 ms Bauzeit) kostet ein GPU-Dispatch samt `getArrayBufferAsync`-Readback mehr Latenz, als er an Rechenzeit spart — und der Worker-Pfad läuft auch dort, wo es kein WebGPU gibt (iPad-Safari, WebGL2-Fallback). Der GPU-Pfad gewinnt, sobald die Kachelauflösung steigt (`resolution` 32/64) oder mehrere Kacheln pro Dispatch gebündelt werden; beides ist der nächste sinnvolle Schritt.

Der GPU-Pfad prüft sich beim Start selbst: er rechnet eine Referenzkachel und vergleicht Höhen und Normalen gegen die CPU-Implementierung. Bei Abweichung, fehlendem WebGPU oder Pipeline-Fehler fällt er automatisch und still auf den Worker-Pfad zurück (Meldung in der Konsole).

## Architektur

```
src/
├── main.ts                    Bootstrap
├── core/
│   ├── Engine.ts              Renderer (WebGPU + Log-Depth), Main-Loop, Input, HUD,
│   │                          adaptive Renderauflösung
│   ├── SceneManager.ts        f64→f32-Brücke: Floating-Origin-Sync pro Frame
│   ├── SimClock.ts            Sim-Zeit ab J2000, Time-Warp
│   └── constants.ts           Einheiten (m, kg, s), astronomische Konstanten
├── math/
│   ├── Vector3d.ts            Double-Precision-Vektor (CPU-Weltkoordinaten)
│   └── rng.ts                 hash32 + mulberry32: deterministische Seeds
├── camera/
│   └── SpaceCamera.ts         Multi-Pointer (Pinch/Drag/Impuls), f64-Weltposition,
│                              Orbit- und Freiflugmodus, exp. Zoom, Terrain-Kollision,
│                              dynamische Near-Plane
├── nav/                       three-frei, offline testbar
│   ├── vec.ts                 f64-Vektorarithmetik auf {x,y,z}
│   ├── types.ts               BodyRef, NavInput, NavFrame
│   ├── proximity.ts           weiche Referenzhöhe (Softmin im Log-Raum)
│   ├── flightKernel.ts        skalenfreies Geschwindigkeitsmodell mit Substepping
│   ├── gotoKernel.ts          Log-Raum-Übergang, analytische Übergabegeschwindigkeit
│   ├── picking.ts             Winkel-Picking + Bildschirmstrahl
│   ├── Navigator.ts           Zustandsmaschine frei ↔ Anflug
│   └── format.ts              HUD-Formatierung (m/km/AE/Lj, m/s/km/s/c)
├── ui/
│   └── FlightControls.ts      Schubregler, Speed-Stufen, Doppeltipp-Erkennung
├── physics/
│   └── Kepler.ts              Bahnelemente, Kepler-Löser, analytische Propagation
├── universe/
│   ├── CelestialBody.ts       Basisklasse, hierarchische Positionen
│   ├── Star.ts / Planet.ts    Konkrete Körper (Licht/Glow bzw. Terrain/Gas)
│   ├── UniverseManager.ts     Hybrid: Katalog + prozedurale Nachbarschaft, lazy
│   └── procedural.ts          Hauptreihen-Sterne, Frostlinie, Masse-Radius
├── terrain/
│   ├── PlanetLOD.ts           Cube-Sphere-Quadtree (Auswahl-Logik, synchron)
│   ├── TerrainProvider.ts     priorisierte Job-Queue, Worker-Pool, Backend-Wahl
│   ├── terrainWorker.ts       Worker-Entry (Transferable-Puffer)
│   ├── gpuTerrain.ts          WGSL-Compute-Kernel via TSL + Selbsttest
│   ├── tileGeometry.ts        THREE-freier Kern: Höhenfeld, Kachel-Assembly, Paletten
│   └── noise.ts               Seedbares 3D-Simplex, fBm, Ridged
└── data/catalog.json          Sol-System, vereinfachte J2000-Bahnelemente

tools/                         Offline-Prüfungen (kein Build, kein node_modules)
├── test-nav.ts                41 Tests der Navigationskerne
├── test-orbit.ts              10 Tests der Kepler-Zustandspropagation
├── register-ts.mjs            Node-Loader-Hooks (Type-Stripping + Auflösung)
├── ts-hooks.mjs
└── stubs/three-webgpu.mjs     Minimalstub, damit Kepler offline läuft
```

Die Module unter `src/nav/` importieren nichts aus dem Projekt und kein three — sie laufen im Browser, im Worker und in Node identisch. `Vector3d` und `Orbit` verwenden seit v0.3 explizite Felder statt Parameter-Properties; Nodes Type-Stripping kann Letztere nicht entfernen, und beide sollen offline prüfbar bleiben.

## Zentrale Entscheidungen

**Präzision ist ein Verbundproblem, kein Depth-Buffer-Problem.** Der logarithmische Depth-Buffer beseitigt Z-Fighting über 0.2 m … 1e19 m — aber Vertex-Jitter entsteht durch große *Positions*-Koordinaten in f32. Daher: (1) absolute Positionen in f64, (2) hierarchisch entlang des Orbitbaums, (3) Camera-Relative Rendering (Kamera immer bei (0,0,0)), (4) Kachelgeometrie relativ zum Kachelzentrum.

**Der GPU-Pfad rechnet nur, was in f32 unkritisch ist.** Der Compute-Kernel liefert Skalarhöhen und Einheitsnormalen; die Positionen entstehen weiterhin in f64 auf dem Main-Thread. Eine in f32 gerechnete Position bei R = 6.4 e6 m trüge ~0.5 m Rauschen — bei 2 m Flughöhe wäre das sichtbar. Höhen und Normalen dagegen haben kleinen Wertebereich bzw. sind normiert.

**Analytische Kepler-Propagation statt Integrator.** Position(t) ist geschlossen lösbar ⇒ Time-Warp ×10⁸ ohne Drift.

**Eine Abstraktion für zwei Welten.** Katalog- und prozedurale Körper sind nach der Instanziierung identische `CelestialBody`-Objekte; die Naht existiert nur in den Fabriken.

**Quadtree synchron, Geometrie asynchron.** Die LOD-Auswahl (Split/Merge mit Hysterese, Rückseiten-Guard, Anfrage-Budget) bleibt deterministisch im Frame. Nur der Kachelbau wandert aus. Lückenfreier Übergang: eine gesplittete Kachel bleibt sichtbar, bis **alle vier** Kinder Geometrie haben — vorher werden die Kinder ausgeblendet, sodass weder Löcher noch doppelt gezeichnete, z-fightende Flächen entstehen. Jobs tragen die Kameradistanz als Priorität; bei voller Queue fallen die fernsten heraus und werden im Folgeframe neu gestellt.

**Normalen aus dem Höhen-Gradienten.** Statt des Kreuzprodukts zweier Oberflächenpunkte (dort löschen sich auf tiefen LOD-Stufen ~6 signifikante Stellen aus) gilt `n = normalize(dir − t₁·∂h/∂s₁ − t₂·∂h/∂s₂)`. Numerisch stabil bis Level 14, nahtlos über Kachelgrenzen und — wichtig — in CPU und WGSL bitweise dieselbe Formel, sodass beide Backends identisch aussehen.

## Bekannte Grenzen / Roadmap

1. **Kacheln bündeln:** mehrere Kacheln pro Compute-Dispatch, dann lohnt sich der GPU-Pfad auch bei kleiner Auflösung.
2. **Detail-Oktaven:** das Höhenfeld hat aktuell 5 Oktaven ab Frequenz ~1.6, d. h. Strukturen ab ~1000 km. Aus 2 m Höhe wirkt der Boden deshalb glatt; LOD-abhängige Detail-Oktaven (+ triplanare Detail-Maps) sind der nächste Qualitätssprung.
3. Atmosphären-Scattering (TSL-Nodes), Sternen-Backdrop/Galaxienkatalog statt leerem Himmel.
4. Achsrotation + rotierende Bezugssysteme.
5. **Stufe 2 — verschachtelte Bezugsrahmen.** Der Flug ist mit v0.3 skalenfrei, die *Koordinaten* sind es nicht: ein einziger f64-Weltursprung bleibt ein einziger Weltursprung, bei ~10³ Lj ist weiter Schluss. `tools/test-orbit.ts` beziffert den Effekt — dasselbe System 3 Lj vom Ursprung verliert in der Geschwindigkeit rund 0,16 m/s allein durch die Rundung der Absolutposition. Danach: Galaxien-Ebene, Octree über Sternregionen, Impostor-Rendering.
6. Orbit-Linien, patched conics für steuerbare Schiffe. *(Picking/Tippen zum Fokussieren ist mit v0.3 erledigt.)*
7. Mond-Bahnelemente sind grob (starke reale Störungen); Katalogelemente generell „vereinfachtes J2000“.
8. T-Junctions werden von Skirts kaschiert, nicht topologisch aufgelöst.
