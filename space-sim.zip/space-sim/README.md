# Space Sim — Foundation (v0.2)

Physikalisch realistischer Weltraumsimulator (SpaceEngine-Stil).
TypeScript · Three.js (WebGPU-Renderer, `three/webgpu`) · Vite.

**Neu in v0.2:** asynchrone Terrain-Erzeugung (Web-Worker-Pool + optionaler WGSL-Compute-Pfad via TSL) und vollständige Touch-Bedienung inkl. Pinch-to-Zoom.

## Setup

Voraussetzungen: Node ≥ 18. WebGPU: Chrome/Edge 113+ (andere Browser nutzen automatisch den WebGL2-Fallback des `WebGPURenderer`).

```bash
npm install
npm run dev        # → http://localhost:5173
```

Geschrieben gegen `three@0.171` / `@types/three@0.171` (gepinnt).

## Steuerung

| Touch | Maus/Tastatur | Wirkung |
|---|---|---|
| Ein Finger ziehen | Ziehen | Um das Ziel rotieren (läuft mit Drehimpuls aus) |
| **Pinch** (zwei Finger) | Scrollen | Exponentieller Zoom (Meter ↔ Lichtjahre) |
| Zwei Finger schwenken | — | Rotieren, gedämpft |
| ◀ ▶ | Tab / Shift+Tab | Ziel durchschalten |
| − + | Scrollen | Zoomen in Stufen |
| ≪ ×n ≫ ❚❚ | `,` `.` `0` `P` | Zeitraffer langsamer / schneller / zurücksetzen / Pause |
| — | 1–9 | Direktwahl (1 = Sonne, 4 = Erde, 5 = Mond, …) |

Der Pinch-Faktor wird direkt als Multiplikator auf die Zieldistanz gelegt: Fingerabstands-*Verhältnis* und exponentieller Zoom sind beide multiplikativ, deshalb fühlt sich die Geste über alle 20 Größenordnungen gleich an.

Demo-Pfad: Erde fokussieren → bis auf ~2 m über die Oberfläche pinchen (Terrain-LOD verfeinert live, Kamera kollidiert mit dem Höhenfeld) → herauszoomen bis das Sol-System schrumpft → mit ▶ einen `PSC-*`-Stern wählen → sein System wird beim Fokussieren lazy generiert.

## Terrain-Backends

Das HUD zeigt das aktive Backend, die Queue-Länge und die Zahl gebauter Kacheln.

| URL | Backend | Beschreibung |
|---|---|---|
| *(Standard)* | `worker` | Pool aus 2–4 Web Workern, Ergebnisse als Transferables |
| `?terrain=gpu` | `gpu` | Höhenfeld + Normalen als WGSL-Compute-Kernel (TSL) |
| `?terrain=sync` | `sync` | Notfallpfad im Main-Thread (nur zum Vergleich/Debuggen) |

**Warum Worker der Standard ist:** bei 19×19-Kacheln (~1.1 ms Bauzeit) kostet ein GPU-Dispatch samt `getArrayBufferAsync`-Readback mehr Latenz, als er an Rechenzeit spart — und der Worker-Pfad läuft auch dort, wo es kein WebGPU gibt (iPad-Safari, WebGL2-Fallback). Der GPU-Pfad gewinnt, sobald die Kachelauflösung steigt (`resolution` 32/64) oder mehrere Kacheln pro Dispatch gebündelt werden; beides ist der nächste sinnvolle Schritt.

Der GPU-Pfad prüft sich beim Start selbst: er rechnet eine Referenzkachel und vergleicht Höhen und Normalen gegen die CPU-Implementierung. Bei Abweichung, fehlendem WebGPU oder Pipeline-Fehler fällt er automatisch und still auf den Worker-Pfad zurück (Meldung in der Konsole).

## Architektur

```
src/
├── main.ts                    Bootstrap
├── core/
│   ├── Engine.ts              Renderer (WebGPU + Log-Depth), Main-Loop, Input, HUD,
│   │                          adaptive Renderauflösung
│   ├── SceneManager.ts        f64→f32-Brücke: Floating-Origin-Sync pro Frame
│   ├── SimClock.ts            Sim-Zeit ab J2000, Time-Warp
│   └── constants.ts           Einheiten (m, kg, s), astronomische Konstanten
├── math/
│   ├── Vector3d.ts            Double-Precision-Vektor (CPU-Weltkoordinaten)
│   └── rng.ts                 hash32 + mulberry32: deterministische Seeds
├── camera/
│   └── SpaceCamera.ts         Multi-Pointer (Pinch/Drag/Impuls), f64-Weltposition,
│                              exp. Zoom, Terrain-Kollision, dynamische Near-Plane
├── physics/
│   └── Kepler.ts              Bahnelemente, Kepler-Löser, analytische Propagation
├── universe/
│   ├── CelestialBody.ts       Basisklasse, hierarchische Positionen
│   ├── Star.ts / Planet.ts    Konkrete Körper (Licht/Glow bzw. Terrain/Gas)
│   ├── UniverseManager.ts     Hybrid: Katalog + prozedurale Nachbarschaft, lazy
│   └── procedural.ts          Hauptreihen-Sterne, Frostlinie, Masse-Radius
├── terrain/
│   ├── PlanetLOD.ts           Cube-Sphere-Quadtree (Auswahl-Logik, synchron)
│   ├── TerrainProvider.ts     priorisierte Job-Queue, Worker-Pool, Backend-Wahl
│   ├── terrainWorker.ts       Worker-Entry (Transferable-Puffer)
│   ├── gpuTerrain.ts          WGSL-Compute-Kernel via TSL + Selbsttest
│   ├── tileGeometry.ts        THREE-freier Kern: Höhenfeld, Kachel-Assembly, Paletten
│   └── noise.ts               Seedbares 3D-Simplex, fBm, Ridged
└── data/catalog.json          Sol-System, vereinfachte J2000-Bahnelemente
```

## Zentrale Entscheidungen

**Präzision ist ein Verbundproblem, kein Depth-Buffer-Problem.** Der logarithmische Depth-Buffer beseitigt Z-Fighting über 0.2 m … 1e19 m — aber Vertex-Jitter entsteht durch große *Positions*-Koordinaten in f32. Daher: (1) absolute Positionen in f64, (2) hierarchisch entlang des Orbitbaums, (3) Camera-Relative Rendering (Kamera immer bei (0,0,0)), (4) Kachelgeometrie relativ zum Kachelzentrum.

**Der GPU-Pfad rechnet nur, was in f32 unkritisch ist.** Der Compute-Kernel liefert Skalarhöhen und Einheitsnormalen; die Positionen entstehen weiterhin in f64 auf dem Main-Thread. Eine in f32 gerechnete Position bei R = 6.4 e6 m trüge ~0.5 m Rauschen — bei 2 m Flughöhe wäre das sichtbar. Höhen und Normalen dagegen haben kleinen Wertebereich bzw. sind normiert.

**Analytische Kepler-Propagation statt Integrator.** Position(t) ist geschlossen lösbar ⇒ Time-Warp ×10⁸ ohne Drift.

**Eine Abstraktion für zwei Welten.** Katalog- und prozedurale Körper sind nach der Instanziierung identische `CelestialBody`-Objekte; die Naht existiert nur in den Fabriken.

**Quadtree synchron, Geometrie asynchron.** Die LOD-Auswahl (Split/Merge mit Hysterese, Rückseiten-Guard, Anfrage-Budget) bleibt deterministisch im Frame. Nur der Kachelbau wandert aus. Lückenfreier Übergang: eine gesplittete Kachel bleibt sichtbar, bis **alle vier** Kinder Geometrie haben — vorher werden die Kinder ausgeblendet, sodass weder Löcher noch doppelt gezeichnete, z-fightende Flächen entstehen. Jobs tragen die Kameradistanz als Priorität; bei voller Queue fallen die fernsten heraus und werden im Folgeframe neu gestellt.

**Normalen aus dem Höhen-Gradienten.** Statt des Kreuzprodukts zweier Oberflächenpunkte (dort löschen sich auf tiefen LOD-Stufen ~6 signifikante Stellen aus) gilt `n = normalize(dir − t₁·∂h/∂s₁ − t₂·∂h/∂s₂)`. Numerisch stabil bis Level 14, nahtlos über Kachelgrenzen und — wichtig — in CPU und WGSL bitweise dieselbe Formel, sodass beide Backends identisch aussehen.

## Bekannte Grenzen / Roadmap

1. **Kacheln bündeln:** mehrere Kacheln pro Compute-Dispatch, dann lohnt sich der GPU-Pfad auch bei kleiner Auflösung.
2. **Detail-Oktaven:** das Höhenfeld hat aktuell 5 Oktaven ab Frequenz ~1.6, d. h. Strukturen ab ~1000 km. Aus 2 m Höhe wirkt der Boden deshalb glatt; LOD-abhängige Detail-Oktaven (+ triplanare Detail-Maps) sind der nächste Qualitätssprung.
3. Atmosphären-Scattering (TSL-Nodes), Sternen-Backdrop/Galaxienkatalog statt leerem Himmel.
4. Achsrotation + rotierende Bezugssysteme.
5. Galaxien-Ebene: Octree über Sternregionen, Impostor-Rendering; hierarchische Koordinatenrahmen jenseits ~10³ Lj.
6. Picking/UI (Tippen zum Fokussieren), Orbit-Linien, patched conics für steuerbare Schiffe.
7. Mond-Bahnelemente sind grob (starke reale Störungen); Katalogelemente generell „vereinfachtes J2000“.
8. T-Junctions werden von Skirts kaschiert, nicht topologisch aufgelöst.
