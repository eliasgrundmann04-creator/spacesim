import * as THREE from 'three/webgpu';
import { SceneManager } from './SceneManager';
import { SimClock } from './SimClock';
import { formatDistance, LY, EARTH_RADIUS } from './constants';
import { SpaceCamera } from '../camera/SpaceCamera';
import { UniverseManager } from '../universe/UniverseManager';
import type { CelestialBody } from '../universe/CelestialBody';
import { TerrainField } from '../terrain/tileGeometry';
import type { TileSpec } from '../terrain/tileGeometry';
import { configureTerrainProvider, getTerrainProvider } from '../terrain/TerrainProvider';
import type { TerrainBackendChoice } from '../terrain/TerrainProvider';

/**
 * Engine: verdrahtet Renderer, Uhr, Universum, Szene und Kamera
 * und besitzt die Main-Loop.
 *
 * Frame-Choreografie (Reihenfolge ist Teil des Vertrags):
 *   1. clock.tick()            → dt (real) & simTime (gewarpt)
 *   2. universe.update()       → analytische Kepler-Propagation aller
 *                                f64-Positionen + Lazy-Systeminstanziierung
 *   3. camera.update()         → f64-Kameraweltposition aus Ziel + Orbit
 *   4. scene.syncToCamera()    → Floating Origin: alles kamerarelativ (f32),
 *                                Per-Body-Hooks (Terrain-LOD, Star-Sprites)
 *   5. terrain.pump()          → Kachel-Jobs nach Kameradistanz priorisiert
 *                                an Worker/GPU verteilen (nie im Frame bauen)
 *   6. renderer.render()       → WebGPU, logarithmischer Depth-Buffer
 */
export class Engine {
  private renderer!: THREE.WebGPURenderer;
  private readonly sceneManager = new SceneManager();
  private readonly clock = new SimClock();
  private camera!: SpaceCamera;
  private universe!: UniverseManager;
  private readonly terrain = getTerrainProvider();

  // Adaptive Renderauflösung (Tablets sind fast immer fillrate-limitiert)
  private maxPixelRatio = 1;
  private renderScale = 1;
  private smoothedFrameMs = 16;
  private lastScaleChange = 0;

  private constructor(
    private readonly container: HTMLElement,
    private readonly hud: HTMLElement,
  ) {}

  static async create(container: HTMLElement, hud: HTMLElement): Promise<Engine> {
    const engine = new Engine(container, hud);
    await engine.init();
    return engine;
  }

  private async init(): Promise<void> {
    if (!('gpu' in navigator)) {
      console.info('[Engine] WebGPU nicht verfügbar — WebGPURenderer nutzt den WebGL2-Fallback.');
    }

    // Log-Depth-Buffer: Tiefenpräzision wird logarithmisch verteilt, damit
    // ein Cockpit in 2 m und ein Mond in 4e8 m im selben Frame ohne
    // Z-Fighting koexistieren. (Alternative auf WebGPU: Reversed-Z; die
    // Wahl ist hier gekapselt und später austauschbar.)
    // Hinweis: Options-Objekt untypisiert übergeben, da die @types-Definitionen
    // der WebGPURenderer-Parameter der Renderer-API teils hinterherhinken.
    const rendererParams = { antialias: true, logarithmicDepthBuffer: true };
    this.renderer = new THREE.WebGPURenderer(rendererParams as never);
    await this.renderer.init();

    this.maxPixelRatio = Math.min(window.devicePixelRatio, 2);
    this.renderScale = this.maxPixelRatio;
    this.renderer.setPixelRatio(this.renderScale);
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.container.appendChild(this.renderer.domElement);

    this.camera = new SpaceCamera(this.renderer.domElement);

    // Terrain-Backend VOR dem Universum konfigurieren: PlanetLOD fordert im
    // Konstruktor bereits die sechs Wurzelkacheln an.
    const backend = await configureTerrainProvider({
      renderer: this.renderer,
      backend: readBackendChoice(),
      probe: buildProbe(),
    });
    console.info(`[Engine] Terrain-Backend: ${backend}`);

    this.universe = new UniverseManager(this.sceneManager);
    this.universe.loadCatalog();                 // reale Körper (Sol-System)
    this.universe.generateNeighborhood(16 * LY); // prozedurale Sterne ringsum

    const start = this.universe.findBody('Erde') ?? this.sceneManager.allBodies[0];
    if (start) this.setTarget(start);

    this.bindInput();
    window.addEventListener('resize', () => this.onResize());
    window.addEventListener('orientationchange', () => this.onResize());

    // Debug-Zugriff in der Konsole
    (window as unknown as { engine: Engine }).engine = this;

    // ---- Main-Loop ----
    this.renderer.setAnimationLoop(() => this.frame());
  }

  private frame(): void {
    const dt = this.clock.tick();

    this.universe.update(this.clock.simTime, this.camera.worldPosition);
    this.camera.update(dt);
    this.sceneManager.syncToCamera(this.camera.worldPosition, dt);
    this.terrain.pump();

    this.adaptResolution(dt);
    this.updateHud();
    this.renderer.render(this.sceneManager.scene, this.camera.camera);
  }

  /**
   * Renderauflösung nachführen. Grob gestuft und mit langer Sperrzeit, weil
   * jede Änderung die Framebuffer neu allokiert — häufiges Nachregeln würde
   * genau das Ruckeln erzeugen, das es verhindern soll.
   */
  private adaptResolution(dt: number): void {
    this.smoothedFrameMs += (dt * 1000 - this.smoothedFrameMs) * 0.05;
    const now = performance.now();
    if (now - this.lastScaleChange < 2500) return;

    let next = this.renderScale;
    if (this.smoothedFrameMs > 26 && this.renderScale > 0.7) next = this.renderScale - 0.25;
    else if (this.smoothedFrameMs < 14 && this.renderScale < this.maxPixelRatio) next = this.renderScale + 0.25;

    next = Math.max(0.7, Math.min(this.maxPixelRatio, next));
    if (Math.abs(next - this.renderScale) < 0.01) return;

    this.renderScale = next;
    this.renderer.setPixelRatio(next);
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.lastScaleChange = now;
  }

  // ------------------------------------------------------------ Interaktion

  private setTarget(body: CelestialBody): void {
    this.universe.populateSystem(body); // prozedurale Sterne beim Fokussieren füllen
    this.camera.focus(body);
  }

  private cycleTarget(direction: 1 | -1): void {
    const bodies = this.sceneManager.allBodies;
    if (bodies.length === 0) return;
    const i = this.camera.target ? bodies.indexOf(this.camera.target) : 0;
    const next = (i + direction + bodies.length) % bodies.length;
    this.setTarget(bodies[next]);
  }

  private action(act: string): void {
    switch (act) {
      case 'prev': this.cycleTarget(-1); break;
      case 'next': this.cycleTarget(1); break;
      case 'in': this.camera.zoomStep(-1); break;
      case 'out': this.camera.zoomStep(1); break;
      case 'slower': this.clock.slower(); break;
      case 'faster': this.clock.faster(); break;
      case 'warp': this.clock.resetWarp(); break;
      case 'pause': this.clock.togglePause(); break;
    }
  }

  private bindInput(): void {
    // Bildschirm-Buttons (Tablet): pointerdown statt click ⇒ keine 300-ms-Verzögerung
    for (const button of document.querySelectorAll<HTMLElement>('#controls button')) {
      button.addEventListener('pointerdown', (e) => {
        e.preventDefault();
        this.action(button.dataset.act ?? '');
      });
    }

    window.addEventListener('keydown', (e) => {
      switch (e.key) {
        case 'Tab':
          e.preventDefault();
          this.cycleTarget(e.shiftKey ? -1 : 1);
          break;
        case '.': this.action('faster'); break;
        case ',': this.action('slower'); break;
        case '0': this.action('warp'); break;
        case 'p': case 'P': this.action('pause'); break;
        default: {
          const n = Number(e.key);
          if (n >= 1 && n <= 9) {
            const body = this.sceneManager.allBodies[n - 1];
            if (body) this.setTarget(body);
          }
        }
      }
    });
  }

  // ------------------------------------------------------------------- HUD

  private updateHud(): void {
    const t = this.camera.target;
    const warpLabel = this.clock.paused ? 'PAUSE' : `×${this.clock.timeWarp.toLocaleString('de-DE')}`;
    const date = this.clock.date.toISOString().replace('T', ' ').slice(0, 16);
    const fps = (1000 / Math.max(this.smoothedFrameMs, 0.01)).toFixed(0);
    const workers = this.terrain.backend === 'worker' ? `×${this.terrain.workerCount}` : '';

    this.hud.textContent =
      `${t ? t.name : '—'}   Höhe ${formatDistance(this.camera.altitude)}   ` +
      `Warp ${warpLabel}   ${date} UTC\n` +
      `${fps} fps @ ${this.renderScale.toFixed(2)}×   ` +
      `Terrain ${this.terrain.backend}${workers}   Queue ${this.terrain.pending}   ` +
      `Kacheln ${this.terrain.built}`;

    const warpButton = document.querySelector<HTMLElement>('#controls [data-act="warp"]');
    if (warpButton) warpButton.textContent = this.clock.paused ? 'Pause' : `×${shortWarp(this.clock.timeWarp)}`;
  }

  private onResize(): void {
    this.renderer.setPixelRatio(this.renderScale);
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.camera.resize(window.innerWidth, window.innerHeight);
  }
}

/** ?terrain=worker|gpu|sync — sonst 'auto' (= Worker, siehe TerrainProvider). */
function readBackendChoice(): TerrainBackendChoice {
  const value = new URLSearchParams(window.location.search).get('terrain');
  return value === 'worker' || value === 'gpu' || value === 'sync' ? value : 'auto';
}

/** Kleine Referenzkachel für den Selbsttest des GPU-Compute-Pfads. */
function buildProbe(): { field: TerrainField; tile: TileSpec } {
  const field = new TerrainField({
    seed: 0x5eed,
    radius: EARTH_RADIUS,
    terrain: {
      amplitude: 0.0018, frequency: 1.6, octaves: 5,
      ocean: true, oceanLevel: 0.02, palette: 'earth',
      maxDepth: 14, resolution: 16,
    },
  });
  const tile: TileSpec = {
    face: 0, level: 3, u0: -0.25, v0: 0.125, resolution: 16,
    centerX: 0, centerY: 0, centerZ: 0,
  };
  return { field, tile };
}

function shortWarp(warp: number): string {
  if (warp < 1000) return String(warp);
  if (warp < 1e6) return `${Math.round(warp / 1e3)}k`;
  return `${(warp / 1e6).toFixed(warp < 1e7 ? 1 : 0)}M`;
}
