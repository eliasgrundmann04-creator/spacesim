import * as THREE from 'three/webgpu';
import { Vector3d } from '../math/Vector3d';
import { LY } from '../core/constants';
import type { CelestialBody } from '../universe/CelestialBody';

/**
 * Kamera für 20 Größenordnungen.
 *
 * Kernidee (Floating Origin): Die Three-Kamera steht IMMER bei (0,0,0).
 * Die "wahre" Position lebt als f64 in worldPosition; der SceneManager
 * platziert jede Frame alle Objekte relativ dazu. f32-Jitter entsteht im
 * Vertex-Shader durch große absolute Koordinaten — nicht im Depth-Buffer —
 * und genau diese großen Koordinaten erreichen die GPU hier nie.
 *
 * Zoom ist exponentiell (Distanz × e^k): dieselbe Geste bewegt nahtlos von 2 m
 * über einer Planetenoberfläche bis auf Lichtjahre hinaus. Genau deshalb passt
 * Pinch perfekt: das Verhältnis der Fingerabstände ist bereits multiplikativ
 * und wird unverändert auf die Zieldistanz angewandt.
 */

const MIN_DISTANCE = 0.5;
const MAX_DISTANCE = 500 * LY;

interface PointerState { x: number; y: number; }

export class SpaceCamera {
  readonly camera: THREE.PerspectiveCamera;
  readonly worldPosition = new Vector3d();

  target: CelestialBody | null = null;

  // Orbit-Zustand um das Ziel (Z-up-Kugelkoordinaten)
  private theta = 0.6;
  private phi = 1.15;
  private distance = 1e7;
  private targetDistance = 1e7;

  // Drehimpuls: lässt Touch-Gesten natürlich auslaufen
  private thetaVel = 0;
  private phiVel = 0;

  private readonly pointers = new Map<number, PointerState>();
  private pinchDistance = 0;
  private pinchX = 0;
  private pinchY = 0;

  private readonly offset = new THREE.Vector3();
  private readonly dir = new THREE.Vector3();

  constructor(private readonly dom: HTMLElement) {
    this.camera = new THREE.PerspectiveCamera(
      55,
      window.innerWidth / window.innerHeight,
      0.2,
      1e19, // far ≫ 16 Lj Nachbarschaft; mit Log-Depth-Buffer unkritisch
    );
    this.camera.up.set(0, 0, 1); // Ekliptik, Z = Norden

    dom.style.touchAction = 'none';
    this.bindPointer();
  }

  // -------------------------------------------------------------- Eingabe

  private bindPointer(): void {
    const dom = this.dom;

    dom.addEventListener('pointerdown', (e) => {
      dom.setPointerCapture(e.pointerId);
      this.pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      this.thetaVel = 0;
      this.phiVel = 0;
      if (this.pointers.size === 2) this.beginPinch();
    });

    dom.addEventListener('pointermove', (e) => {
      const prev = this.pointers.get(e.pointerId);
      if (!prev) return;
      const dx = e.clientX - prev.x;
      const dy = e.clientY - prev.y;
      prev.x = e.clientX;
      prev.y = e.clientY;

      if (this.pointers.size === 1) this.rotateBy(dx, dy, 1);
      else if (this.pointers.size === 2) this.updatePinch();
    });

    const release = (e: PointerEvent): void => {
      if (!this.pointers.delete(e.pointerId)) return;
      if (dom.hasPointerCapture(e.pointerId)) dom.releasePointerCapture(e.pointerId);
      // Bei 3 → 2 Fingern die Pinch-Basis neu setzen, sonst springt der Zoom
      if (this.pointers.size === 2) this.beginPinch();
      else this.pinchDistance = 0;
    };
    dom.addEventListener('pointerup', release);
    dom.addEventListener('pointercancel', release);
    window.addEventListener('blur', () => {
      this.pointers.clear();
      this.pinchDistance = 0;
    });

    dom.addEventListener(
      'wheel',
      (e) => {
        e.preventDefault();
        this.zoomBy(Math.exp(e.deltaY * 0.0015));
      },
      { passive: false },
    );

    // iOS-Safari: Seiten-Zoom per Pinch unterbinden, damit die Geste bei uns ankommt
    for (const type of ['gesturestart', 'gesturechange', 'gestureend']) {
      dom.addEventListener(type, (e: Event) => e.preventDefault());
    }
    dom.addEventListener('contextmenu', (e) => e.preventDefault());
  }

  /** Sensitivität relativ zur kürzeren Bildschirmkante ⇒ auf Tablet und Desktop gleich. */
  private rotateBy(dx: number, dy: number, scale: number): void {
    const k = (2.2 / Math.min(window.innerWidth, window.innerHeight)) * scale;
    this.thetaVel = -dx * k;
    this.phiVel = -dy * k;
    this.theta += this.thetaVel;
    this.phi = THREE.MathUtils.clamp(this.phi + this.phiVel, 0.02, Math.PI - 0.02);
  }

  private zoomBy(factor: number): void {
    this.targetDistance = THREE.MathUtils.clamp(
      this.targetDistance * factor, MIN_DISTANCE, MAX_DISTANCE,
    );
  }

  private twoPointers(): [PointerState, PointerState] {
    const it = this.pointers.values();
    return [it.next().value as PointerState, it.next().value as PointerState];
  }

  private beginPinch(): void {
    const [a, b] = this.twoPointers();
    this.pinchDistance = Math.hypot(a.x - b.x, a.y - b.y) || 1;
    this.pinchX = (a.x + b.x) / 2;
    this.pinchY = (a.y + b.y) / 2;
  }

  private updatePinch(): void {
    const [a, b] = this.twoPointers();
    const dist = Math.hypot(a.x - b.x, a.y - b.y) || 1;
    const midX = (a.x + b.x) / 2;
    const midY = (a.y + b.y) / 2;

    if (this.pinchDistance > 0) {
      // Auseinanderziehen (dist wächst) ⇒ heranzoomen ⇒ Distanz sinkt
      this.zoomBy(this.pinchDistance / dist);
      // Zwei-Finger-Schwenk rotiert zusätzlich, gedämpft
      this.rotateBy(midX - this.pinchX, midY - this.pinchY, 0.6);
    }

    this.pinchDistance = dist;
    this.pinchX = midX;
    this.pinchY = midY;
  }

  // ------------------------------------------------------------ Steuerung

  focus(body: CelestialBody): void {
    this.target = body;
    this.targetDistance = body.radius * 6;
    this.distance = this.targetDistance;
    this.thetaVel = 0;
    this.phiVel = 0;
  }

  /** Für Bildschirm-Buttons auf Geräten ohne Tastatur/Mausrad. */
  zoomStep(direction: 1 | -1): void {
    this.zoomBy(Math.exp(direction * 0.35));
  }

  update(dt: number): void {
    const t = this.target;
    if (!t) return;

    // Drehimpuls auslaufen lassen, solange kein Finger auf dem Glas liegt
    if (this.pointers.size === 0 && (this.thetaVel !== 0 || this.phiVel !== 0)) {
      const decay = Math.exp(-dt * 5);
      this.thetaVel *= decay;
      this.phiVel *= decay;
      this.theta += this.thetaVel;
      this.phi = THREE.MathUtils.clamp(this.phi + this.phiVel, 0.02, Math.PI - 0.02);
      if (Math.abs(this.thetaVel) < 1e-5 && Math.abs(this.phiVel) < 1e-5) {
        this.thetaVel = 0;
        this.phiVel = 0;
      }
    }

    // Zoom im Log-Raum glätten (gleichmäßig über alle Größenordnungen)
    const s = 1 - Math.exp(-dt * 8);
    this.distance = Math.exp(
      THREE.MathUtils.lerp(Math.log(this.distance), Math.log(this.targetDistance), s),
    );

    // Blickrichtung → Bodenhöhe unter der Kamera sampeln (echte Meter-Ebene:
    // Mindestdistanz folgt dem lokalen Terrain, nicht nur dem Kugelradius)
    const sinPhi = Math.sin(this.phi);
    this.dir.set(
      sinPhi * Math.cos(this.theta),
      sinPhi * Math.sin(this.theta),
      Math.cos(this.phi),
    );
    const minD = t.radius + t.getSurfaceOffset(this.dir) + 2;
    if (this.targetDistance < minD) this.targetDistance = minD;
    if (this.distance < minD) this.distance = minD;

    // f64-Weltposition = Zielposition + Orbit-Offset
    this.offset.copy(this.dir).multiplyScalar(this.distance);
    this.worldPosition.set(
      t.position.x + this.offset.x,
      t.position.y + this.offset.y,
      t.position.z + this.offset.z,
    );

    // Floating Origin: Kamera bleibt im Ursprung, blickt zum (relativen) Ziel
    this.camera.position.set(0, 0, 0);
    this.camera.lookAt(-this.offset.x, -this.offset.y, -this.offset.z);

    // Dynamische Near-Plane: verteilt die Log-Depth-Auflösung sinnvoll und
    // verbessert das Culling — von 20 cm am Boden bis 10^6 m im Deep Space.
    const altitude = Math.max(this.distance - t.radius, 1);
    const near = THREE.MathUtils.clamp(altitude * 1e-3, 0.2, 1e6);
    if (Math.abs(near - this.camera.near) / this.camera.near > 0.1) {
      this.camera.near = near;
      this.camera.updateProjectionMatrix();
    }
  }

  get altitude(): number {
    return this.target ? this.distance - this.target.radius : 0;
  }

  resize(width: number, height: number): void {
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
  }
}
